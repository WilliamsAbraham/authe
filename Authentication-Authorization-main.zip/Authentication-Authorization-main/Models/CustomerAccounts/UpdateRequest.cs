﻿using System.ComponentModel.DataAnnotations;
using WashryteAPI.Entities;

namespace WashryteAPI.Models.Accounts
{
    public class UpdateRequest
    {
       
   
        private string _email;

        public string Name { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public byte[] Image { get; set; }
      

       
        
        [EmailAddress]
        public string Email
        {
            get => _email;
            set => _email = replaceEmptyWithNull(value);
        }

      

        // helpers

        private string replaceEmptyWithNull(string value)
        {
            // replace empty string with null to make field optional
            return string.IsNullOrEmpty(value) ? null : value;
        }
    }
}

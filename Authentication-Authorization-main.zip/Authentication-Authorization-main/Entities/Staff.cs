﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WashryteAPI.Entities
{
    public class Staff
    {
        [Key]
            public int Id { get; set; }
            public string staff_number { get; set; }
            public string store_id { get; set; }
            public string bank_id { get; set; }
            public decimal Salary { get; set; }
            public string account_number { get; set; }
            public string working_hours { get; set; }
            public bool is_available { get; set; }

            public User Users { get; set; }

           
    }
    
}

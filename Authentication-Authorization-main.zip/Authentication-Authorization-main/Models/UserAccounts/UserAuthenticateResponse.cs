﻿using System;
using System.Text.Json.Serialization;

namespace WashryteAPI.Models.StaffAccounts
{
    public class UserAuthenticateResponse
    {
        public int Id { get; set; }
        public string Phone { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Role { get; set; }
        public DateTime Created { get; set; }
        public DateTime? Updated { get; set; }
       public string access_token { get; set; }

        
    }

}

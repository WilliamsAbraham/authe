﻿
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Threading.Tasks;
using WashryteAPI.Helpers;

namespace WashryteAPI.Services
{
    public interface IEmailSender
    {
        void Send(string to, string subject, string html, string from = null);
    }
    public class EmailSender:IEmailSender
    {
        public EmailSender(
            IOptions<AppSettings> options
            )
        {
            this.Options = options.Value;
        }

        public AppSettings Options { get; set; }




        public async void Send(string to, string subject, string html, string from = null)
        {
            // create message
            var client = new SendGridClient(Options.ApiKey);
            var msg = new SendGridMessage()
            {
                From = new EmailAddress(Options.SenderEmail, Options.SenderName),
                Subject = subject,
                PlainTextContent = html,
                HtmlContent = html
            };

            // send email
            msg.AddTo(new EmailAddress(to));

            // disable tracking settings
            // ref.: https://sendgrid.com/docs/User_Guide/Settings/tracking.html
            msg.SetClickTracking(false, false);
            msg.SetOpenTracking(false);
            msg.SetGoogleAnalytics(false);
            msg.SetSubscriptionTracking(false);

             await client.SendEmailAsync(msg);
        }
    }

}

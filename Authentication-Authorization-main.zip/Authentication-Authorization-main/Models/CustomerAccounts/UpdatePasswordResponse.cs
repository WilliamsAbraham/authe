﻿namespace WashryteAPI.Models.Accounts
{
    public class UpdatePasswordResponse

    {
        public string CurrentPassword { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}

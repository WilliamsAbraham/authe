﻿using AutoMapper;
using BC = BCrypt.Net.BCrypt;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using WashryteAPI.Entities;
using WashryteAPI.Helpers;
using WashryteAPI.Models.StaffAccounts;



namespace WashryteAPI.Services
{
    public interface IUserAccountService
    {
        UserAuthenticateResponse Authenticate(UserAuthenticateRequest model);
        
      
        void ForgotPassword(UserForgotPasswordRequest model, string origin);
       
        void ResetPassword(UserResetPasswordRequest model, int id);
        IEnumerable<UserAccountResponse> GetAll();
        UserAccountResponse GetById(int id);
       
        UserAccountResponse Update(int id, UserUpdateRequest model);
        void ChangePassword(int id, UserUpdatePasswordRequest model);
        void Register( UserRegisterRequest model ,string origin);

        void Delete(int id);
    }
    public class UserAccountService:IUserAccountService
    {
        private readonly DataContext _context;
        private readonly IMapper _mapper;
        private readonly AppSettings _appSettings;
        private readonly IEmailSender _emailSender;

        public UserAccountService(
            DataContext context,
            IMapper mapper,
            IOptions<AppSettings> appSettings,
            IEmailSender emailSender)
        {
            _context = context;
            _mapper = mapper;
            _appSettings = appSettings.Value;
            _emailSender = emailSender;
        }

        public UserAuthenticateResponse Authenticate(UserAuthenticateRequest model)
        {
            var account = _context.Users.FirstOrDefault(x => x.email == model.Email);

            if (account == null || !BC.Verify(model.Password, account.password))
                throw new AppException("Email or password is incorrect");

            // authentication successful so generate jwt and refresh tokens
            // var jwtToken = generateSJwtToken(account);

            // save changes to db
            account.access_token = generateCustomerJwtToken(account);
            _context.Update(account);
            _context.SaveChanges();

            var response = _mapper.Map<UserAuthenticateResponse>(account);
            response.access_token = account.access_token;
            
            return response;
        }


        public void Register (UserRegisterRequest model, string origin)
        {
            //// validate
            //if (_context.Staff.Any(x => x.Email == model.Email))
            //{
            //    // send already registered error in email to prevent account enumeration
            //    sendAlreadyRegisteredEmail(model.Email, origin);
            //    return;
            //}

            // map model to new account object
            var account = _mapper.Map<User>(model);


            account.created_at = DateTime.UtcNow;

            // hash password
            account.password = BC.HashPassword(model.Password);

            // save account
            _context.Users.Add(account);
            _context.SaveChanges();

            // send email
            //sendLoginEmail(account, origin);
        }


        public void ForgotPassword(UserForgotPasswordRequest model, string origin)
        {
            var account = _context.Users.SingleOrDefault(x => x.email == model.Email);

            // always return ok response to prevent email enumeration
            if (account == null) return;


            // create reset token that expires after 1 day
            account.reset_token = randomTokenString();
            account.reset_token_expired_at = DateTime.UtcNow.AddDays(1);
            _context.Users.Update(account);
            _context.SaveChanges();

            // send email
            sendPasswordResetEmail(account, origin);
        }

       

        public void ResetPassword(UserResetPasswordRequest model, int id)
        {
            var account = _context.Users.FirstOrDefault(x =>x.reset_token == model.Token && x.reset_token_expired_at > DateTime.UtcNow);

            if (account == null)
                throw new AppException("Invalid Token");

            // update password and remove reset token
            account.password = BC.HashPassword(model.Password);
            account.reset_token = null;
            account.reset_token_expired_at = null;
            account.password_rest_at = DateTime.UtcNow;
            _context.Users.Update(account);
            _context.SaveChanges();
        }

        public IEnumerable<UserAccountResponse> GetAll()
        {
            var accounts = _context.Users;
            return _mapper.Map<IList<UserAccountResponse>>(accounts);
        }

        public UserAccountResponse GetById(int id)
        {
            var account = getAccount(id);
            return _mapper.Map<UserAccountResponse>(account);
        }

        

        public UserAccountResponse Update(int id, UserUpdateRequest model)
        {
            var account = getAccount(id);

            // validate
            if (account.email != model.Email && _context.Users.Any(x => x.email == model.Email))
                throw new AppException($"Email '{model.Email}' is already taken");

            // hash password if it was entered
            if (!string.IsNullOrEmpty(model.Password))
                account.password = BC.HashPassword(model.Password);

            // copy model to account and save
            _mapper.Map(model, account);
            account.updated_at = DateTime.UtcNow;
            _context.Users.Update(account);
            _context.SaveChanges();

            return _mapper.Map<UserAccountResponse>(account);
        }

        public void ChangePassword(int id, UserUpdatePasswordRequest model)
        {
            var account = getAccount(id);
            //Validate
            if (account == null || !BC.Verify(model.CurrentPassword, account.password))

                throw new AppException("Current Password is incorrect");

            // copy model to account and save
            _mapper.Map(model, account);
            account.password = BC.HashPassword(model.Password);
            _context.Users.Update(account);
            _context.SaveChanges();

           

           
        }

        public void Delete(int id)
        {
            var account = getAccount(id);
            _context.Users.Remove(account);
            _context.SaveChanges();
        }

        // helper methods

        private User getAccount(int id)
        {
            var account = _context.Users.Find(id);
            if (account == null) throw new KeyNotFoundException("Account not found");
            return account;
        }

        

        private string generateCustomerJwtToken(User account)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.SecretB);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("id", account.Id.ToString()) }),
                Expires = DateTime.UtcNow.AddMinutes(60),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private string randomTokenString()
        {
            using var rngCryptoServiceProvider = new RNGCryptoServiceProvider();
            var randomBytes = new byte[6];
            rngCryptoServiceProvider.GetBytes(randomBytes);
            // convert random bytes to hex string
            return BitConverter.ToString(randomBytes).Replace("-", "");
        }

        private void sendPasswordResetEmail(User account, string origin)
        {
            string message;
            if (!string.IsNullOrEmpty(origin))
            {
                var resetUrl = $"{origin}/account/resetpassword?token = {account.reset_token}";
                message = $@"<p>Please click the below link to reset your password:</p>
                             <p><a href=""{resetUrl}"">{resetUrl}</a></p>";
            }
            else
            {
                message = $@"<p>Please use the following code to reset your password
                    </p><p><code>{account.reset_token}</code></p>";

            }

            _emailSender.Send(
                to: account.email,
                subject: "Password - Reset - Mail - Reset Password",
                html: $@"<h4>Reset Password Email</h4>
                         {message}"
            );
        }

        private void sendAlreadyRegisteredEmail(string email, string origin)
        {
            string message;
            if (!string.IsNullOrEmpty(origin))
                message = $@"<p>If you don't know your password please visit the <a href=""{origin}/Customer/forgotpassword"">forgot password</a> page.</p>";
            else
                message = "<p>If you don't know your password you can reset it via the <code>/Customer/forgotpassword</code></p>";

            _emailSender.Send(
                to: email,
                subject: "Sign-up Verification For Washryte Account - Email Already Registered",
                html: $@"<h4>Email Already Registered</h4>
                         <p>Your email <strong>{email}</strong> is already registered.</p>
                         {message}"
            );
        }

    }
}

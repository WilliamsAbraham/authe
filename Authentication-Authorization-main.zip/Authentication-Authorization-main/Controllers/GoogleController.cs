﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WashryteAPI.Entities;
using WashryteAPI.Models.Accounts;
using WashryteAPI.Services;
namespace WashryteAPI.Controllers
{
    [CustomerAuthorize]
    public class GoogleController : GoogleBaseController

    {
        private readonly IUserService _userService;

        public GoogleController(UserManager<AccountResponse> userManager, IUserService userService) : base(userManager)
        {
            _userService = userService;
        }
        [AllowAnonymous]
        [HttpPost]

        public async Task<ActionResult> GoogleAuthenticate([FromBody] GoogleUserRequest request)
        {
            if (!ModelState.IsValid)
               
                return BadRequest(ModelState.Values.SelectMany(it => it.Errors).SelectMany(it => it.ErrorMessage));
           
            return Ok(GenerateUserToken(await _userService.AuthenticateGoogleUserAsync(request)));



        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult<AuthenticateResponse> Authenticate(GoogleUserRequest model)
        {
            var response = _userService.AuthenticateGoogleUserAsync(model);

            return Ok(response);
        }
        #region private methods
        private UserToken GenerateUserToken(AccountResponse user)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(Startup.StaticConfig["Authentication:Jwt:Secret"]);

            var expires = DateTime.UtcNow.AddMinutes(60);
            var tokenDecriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                   // new Claim(ClaimTypes.Name,user.Id),
                   // new Claim(JwtRegisteredClaimNames.Sub, Startup.StaticConfig["Authentication:Jwt:Subject"]),

                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                   // new Claim(ClaimTypes.Name, user.Id),
                    new Claim(ClaimTypes.Surname, user.FirstName),
                    new Claim(ClaimTypes.GivenName, user.LastName),
                    new Claim(ClaimTypes.NameIdentifier, user.UserName),
                    new Claim(ClaimTypes.Email, user.Email)

                }),
                Expires = expires,

                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                //Issuer = Startup.StaticConfig["Authentication:Jwt:Issuer"],
                //Audience = Startup.StaticConfig["Authentication:Jwt:Audience"]

            };


            var securityToken = tokenHandler.CreateToken(tokenDecriptor);
            var token = tokenHandler.WriteToken(securityToken);
            return new UserToken
            {
                //UserId = Convert.ToString(user.Id),
                UserId = user.Social_auth_id,

                Email = user.Email,
                Token = token,
                Expires = expires,
            };
        }
        #endregion

    }



}


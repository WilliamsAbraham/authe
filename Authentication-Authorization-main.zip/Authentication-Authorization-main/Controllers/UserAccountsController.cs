﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using WashryteAPI.Entities;
using WashryteAPI.Models.StaffAccounts;


using WashryteAPI.Services;



namespace WashryteAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController:BaseController
    {
        private readonly IMapper _mapper;         
        private readonly IUserAccountService _UserAccountService;
          


        public UserController(
            IUserAccountService UserAccountService,
            
            IMapper mapper)
        {
            _mapper = mapper;

            _UserAccountService = UserAccountService;
          
        }

        [HttpPost("authenticate")]
        public ActionResult<UserAuthenticateResponse> Authenticate(UserAuthenticateRequest model)
        {
            var response = _UserAccountService.Authenticate(model);
            
            return Ok(response);
        }


        [HttpPost("register")]
        public IActionResult Register(UserRegisterRequest model)
        {
            _UserAccountService.Register(model, Request.Headers["origin"]);
            return Ok(new { message = "Registration successful, please check your email for verification instructions" });
        }

        [HttpPost("forgotpassword")]
        public IActionResult ForgotPassword(UserForgotPasswordRequest model)
        {
            _UserAccountService.ForgotPassword(model, Request.Headers["origin"]);
            return Ok(new { message = "Please check your email for password reset instructions" });
        }

       

        [HttpPost("resetpassword")]
        public IActionResult ResetPassword(UserResetPasswordRequest model, int id)
        {
            _UserAccountService.ResetPassword(model, id);
            return Ok(new { message = "Password reset successful, you can now login" });
        }


        [UserAuthorize]
        [HttpPatch("changepassword/{id:int}")]
        public IActionResult ChangePassword(int id, UserUpdatePasswordRequest model)
        {
            // users can Change their Password only
            if (id != Staff.Id)
                return Unauthorized(new { message = "Unauthorized" });

                 _UserAccountService.ChangePassword(id, model);

            return Ok(new { message = "Password Changed Successfully" });
            



        }

        

        



    }
}

﻿using System;
using System.Collections.Generic;

namespace WashryteAPI.Entities
{
    public class User
    {
        public int Id { get; set; }     
        public string name { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string address { get; set; }
        public string access_token { get; set; }    
        public string reset_token { get; set; }  
        
        public DateTime? reset_token_expired_at { get; set; }
        public DateTime? password_rest_at { get; set; }

        public DateTime created_at { get; set; }
        public DateTime? updated_at { get; set; }
        public DateTime? deleted_at { get; set; }

        public Role Role { get; set; }

        public List <Staff> Staffs { get; set; }
        public List<UserRefreshToken> userRefreshTokens { get; set; }

        public bool OwnsToken (string Token) 
        {
            return this.userRefreshTokens.Find(x=>x.token == Token)!=null;
        }
    }
}

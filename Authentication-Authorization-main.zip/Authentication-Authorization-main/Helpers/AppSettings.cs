﻿namespace WashryteAPI.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
        public string SecretB { get; set; }


        // refresh token time to live (in days), inactive tokens are
        // automatically deleted from the database after this time

        public string ApiKey { get; set; }

            public string SenderEmail { get; set; }

            public string SenderName { get; set; }
        
    
    }
}

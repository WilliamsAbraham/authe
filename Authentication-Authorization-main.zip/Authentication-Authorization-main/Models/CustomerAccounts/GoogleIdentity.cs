﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
namespace WashryteAPI.Models.Accounts
{
    public class GoogleUserRequest
    {
        public const string PROVIDER = "google";

        [JsonProperty("idToken")]
        [Required]

        public string IdToken { get; set; }


    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WashryteAPI.Entities;
namespace WashryteAPI.Helpers
{
    public class DataContext : DbContext
    {

        
        public DbSet<User> Users { get; set; }
        public DbSet<Customer> Customers { get; set; }

        private readonly IConfiguration Configuration;

        public DataContext(IConfiguration configuration)
        {
            Configuration = configuration;
        }



        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            // connect to mysql database
            var connectionString = Configuration.GetConnectionString("WebApiDatabase");
            options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
        }
    }
    
}

﻿
using AutoMapper;
using BC = BCrypt.Net.BCrypt;

using Microsoft.Extensions.Options;
using System.Security.Cryptography;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WashryteAPI.Entities;
using WashryteAPI.Helpers;
using WashryteAPI.Models.Accounts;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace WashryteAPI.Services
{
    public interface ICustomerAccountService
    {
        AuthenticateResponse Authenticate(AuthenticateRequest model);

       // AuthenticateResponse RefreshToken(string token, string ipAddress);
        
        void Register(RegisterRequest model, string origin);
      
        void ForgotPassword(ForgotPasswordRequest model, string origin);
        
        void ResetPassword(ResetPasswordRequest model);
        IEnumerable<AccountResponse> GetAll();
        AccountResponse GetById(int id);
       
        AccountResponse Update(int id, UpdateRequest model);
        void Changepassword(int id, UpdatePasswordRequest model);
        
        void Delete(int id);
    }

    public class CustomerAccountService : ICustomerAccountService
    {
        private readonly DataContext _context;
        private readonly IMapper _mapper;
        private readonly AppSettings _appSettings;
        private readonly IEmailSender _emailSender;

        public CustomerAccountService(
            DataContext context,
            IMapper mapper,
            IOptions<AppSettings> appSettings,
            IEmailSender emailSender)
        {
            _context = context;
            _mapper = mapper;
            _appSettings = appSettings.Value;
            _emailSender = emailSender;
        }

        public AuthenticateResponse Authenticate(AuthenticateRequest model)
        {
            var account = _context.Customers.FirstOrDefault(x => x.email == model.Email);

            if (account == null || !BC.Verify(model.Password, account.password))
                throw new AppException("Email or password is incorrect");

            // authentication successful so generate jwt and refresh tokens
            // var jwtToken = generateJwtToken(account);


            // save changes to db
            account.access_token = generateJwtToken(account);
            _context.Update(account);
            _context.SaveChanges();

            var response = _mapper.Map<AuthenticateResponse>(account);
            response.access_token = account.access_token;
            //response.RefreshToken = refreshToken.Token;
            return response;
        }

       

        

        public void Register(RegisterRequest model, string origin)
        {
            // validate
            if (_context.Customers.Any(x => x.email == model.Email))
            {
                // send already registered error in email to prevent account enumeration
                sendAlreadyRegisteredEmail(model.Email, origin);
                return;
            }

            // map model to new account object
            var account = _mapper.Map<Customer>(model);

           
            account.created_at = DateTime.UtcNow;
           
            // hash password
            account.password = BC.HashPassword(model.Password);

            // save account
            _context.Customers.Add(account);
            _context.SaveChanges();

            // send email
           sendLoginEmail(account, origin);
        }

        

        public void ForgotPassword(ForgotPasswordRequest model, string origin)
        {
            var account = _context.Customers.SingleOrDefault(x => x.email == model.Email);

            // always return ok response to prevent email enumeration
            if (account == null) return;


           // create reset token that expires after 1 day
            account.reset_token = randomTokenString();
            account.reset_token_expired_at = DateTime.UtcNow.AddDays(1);
            _context.Customers.Update(account);
            _context.SaveChanges();

            // send email
            sendPasswordResetEmail(account, origin);
        }

        

        public void ResetPassword(ResetPasswordRequest model)
        {
            var account = _context.Customers.SingleOrDefault(x => x.reset_token == model.Token && x.reset_token_expired_at > DateTime.UtcNow);



            if (account == null)
              throw new AppException("Invalid Token");

            // update password and remove reset token

            account.password = BC.HashPassword(model.Password);

            account.reset_token = null;
            account.password_reset_at = DateTime.UtcNow;
            account.reset_token = null;
            _context.Customers.Update(account);
            _context.SaveChanges();
        }

        public IEnumerable<AccountResponse> GetAll()
        {
            var accounts = _context.Customers;
            return _mapper.Map<IList<AccountResponse>>(accounts);
        }

        public AccountResponse GetById(int id)
        {
            var account = getAccount(id);
            return _mapper.Map<AccountResponse>(account);
        }

       

        public AccountResponse Update(int id, UpdateRequest model)
        {
            var account = getAccount(id);

            // validate
            if (account.email != model.Email && _context.Customers.Any(x => x.email == model.Email))
                throw new AppException($"Email '{model.Email}' is already taken");

            // copy model to account and save
            _mapper.Map(model, account);
            account.updated_at = DateTime.UtcNow;
            _context.Customers.Update(account);
            _context.SaveChanges();

            return _mapper.Map<AccountResponse>(account);
        }


        public void Changepassword(int id, UpdatePasswordRequest model)
        {
            var account = getAccount(id);
            //Validate
            if (account==null ||!BC.Verify(model.CurrentPassword, account.password))

               throw new AppException( "Current Password entered is incorrect");
            // copy model to account and save

         
            _mapper.Map(model, account);
            account.password = BC.HashPassword(model.Password);


            account.updated_at = DateTime.UtcNow;


            _context.Customers.Update(account);
            _context.SaveChanges();

            //return _mapper.Map<UpdatePasswordResponse>(account);

          
        }
        
        public void Delete(int id)
        {
            var account = getAccount(id);
            _context.Customers.Remove(account);
            _context.SaveChanges();
        }

        // helper methods

        private Customer getAccount(int id)
        {
            var account = _context.Customers.Find(id);
            if (account == null) throw new KeyNotFoundException("Account not found");
            return account;
        }

      

        private string generateJwtToken(Customer account)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("id", account.Id.ToString()) }),
                Expires = DateTime.UtcNow.AddMinutes(60),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private string randomTokenString()
        {
            using var rngCryptoServiceProvider = new RNGCryptoServiceProvider();
            var randomBytes = new byte[6];
            rngCryptoServiceProvider.GetBytes(randomBytes);
            // convert random bytes to hex string
            return BitConverter.ToString(randomBytes).Replace("-", "");
        }

        private void sendLoginEmail(Customer account, string origin)
        {
            string message;
            if (!string.IsNullOrEmpty(origin))
            {
               
                message = $@"<p>Please click the below link to Log into your Account using the following link <a href = 
                                        ""{origin}/ Customer/Authenticate""> Login Page.:</p>";
                             
            }
            else
            {
                message = $@"<p>Your Account has been registered,You can now go back and login into your Account </p>";
                            
            }

            _emailSender.Send(
                to: account.email,
                subject: "Washryte Account Sign-up Verification - Login to Account",
                html: $@"<h4>Verify Email</h4>
                         <p>Thanks for registering!</p>
                         {message}"
            );
        }

        private void sendAlreadyRegisteredEmail(string email, string origin)
        {
            string message;
            if (!string.IsNullOrEmpty(origin))
                message = $@"<p>If you don't know your password please visit the <a href=""{origin}/Customer/forgotpassword"">forgot password</a> page.</p>";
            else
                message = "<p>If you don't know your password you can reset it via the <code>/Customer/forgotpassword</code></p>";

            _emailSender.Send(
                to: email,
                subject: "Sign-up Verification For Washryte Account - Email Already Registered",
                html: $@"<h4>Email Already Registered</h4>
                         <p>Your email <strong>{email}</strong> is already registered.</p>
                         {message}"
            );
        }

        private void sendPasswordResetEmail(Customer account, string origin)
        {
            string message;
            if (!string.IsNullOrEmpty(origin))
            {
                var resetUrl = $"{origin}/account/resetpassword?token = {account.reset_token}";
                message = $@"<p>Please click the below link to reset your password:</p>
                             <p><a href=""{resetUrl}"">{resetUrl}</a></p>";
            }
            else
            {
                message = $@"<p>Please use the following link to reset your password with the <code>/Customer/resetpassword</code>.
                    </p><p><code>{account.reset_token}</code></p>";
                            
            }

            _emailSender.Send(
                to: account.email,
                subject: "Sign-up Verification For Washryte Account - Reset Password",
                html: $@"<h4>Reset Password Email</h4>
                         {message}"
            );
        }

        
    }
}

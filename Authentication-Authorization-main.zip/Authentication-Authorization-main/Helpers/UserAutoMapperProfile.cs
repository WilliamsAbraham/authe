﻿using AutoMapper;
using WashryteAPI.Entities;
using WashryteAPI.Models.StaffAccounts;
namespace WashryteAPI.Helpers
{
    public class UserAutoMapperProfile: Profile
    {
        // mappings between model and entity objects
        public UserAutoMapperProfile()
        {
            CreateMap<User, UserAccountResponse>();

            CreateMap<UserRegisterRequest, User>();

            CreateMap<User, UserAuthenticateResponse>();

            CreateMap<UserUpdatePasswordRequest, User>();

            CreateMap<UserUpdateRequest, User > ()

                .ForAllMembers(x => x.Condition(
                    (src, dest, prop) =>
                    {
                        // ignore null & empty string properties
                        if (prop == null) return false;
                        if (prop.GetType() == typeof(string) && string.IsNullOrEmpty((string)prop)) return false;

                        // ignore null role
                        if (x.DestinationMember.Name == "Role" && src.Role == null) return false;

                        return true;
                    }
                ));
        }
    }
}

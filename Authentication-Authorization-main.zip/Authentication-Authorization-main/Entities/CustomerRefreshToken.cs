﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System;

namespace WashryteAPI.Entities
{
    [Owned]
    public class CustomerRefreshToken
    {
        [Key]
        public int Id { get; set; }

        public Customer Customer  { get; set; }
        public string token { get; set; }
        public DateTime expires { get; set; }
        public bool is_expired => DateTime.UtcNow >= expires;
        public DateTime created_at { get; set; }
        public string created_byIp { get; set; }
        public DateTime? revoked { get; set; }
        public string revoked_byIp { get; set; }
        public string replaced_bytoken { get; set; }
        public bool is_active => revoked == null && !is_expired;
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

using WashryteAPI.Entities;

namespace WashryteAPI.Controllers
{
    [Controller]
    public abstract class BaseController : ControllerBase
    {
        // returns the current authenticated account (null if not logged in)
       
        public Customer Customer => (Customer)HttpContext.Items["Customer"];
        public Staff Staff => (Staff)HttpContext.Items["Staff"];
    }
}

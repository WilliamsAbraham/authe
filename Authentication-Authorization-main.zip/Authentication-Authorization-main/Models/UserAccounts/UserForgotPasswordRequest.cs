﻿using System.ComponentModel.DataAnnotations;

namespace WashryteAPI.Models.StaffAccounts
{
    public class UserForgotPasswordRequest
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}

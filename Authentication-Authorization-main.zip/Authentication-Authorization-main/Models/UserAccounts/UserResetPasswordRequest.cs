﻿using System.ComponentModel.DataAnnotations;

namespace WashryteAPI.Models.StaffAccounts
{
    public class UserResetPasswordRequest
    {


        [Required]
        public string Token { get; set; }

        [Required]
        [MinLength(6)]
        public string Password { get; set; }

        [Required]
        [Compare("Password", ErrorMessage = " The password entered does not match")]
        public string ConfirmPassword { get; set; }
    }
}

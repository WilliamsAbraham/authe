﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using WashryteAPI.Models.Accounts;
//using Microsoft.AspNetCore.Mvc;
using WashryteAPI.Entities;
namespace WashryteAPI.Controllers
{
    [Route("[controller]/[action]")]
    public abstract class GoogleBaseController : Controller
    { 
        protected readonly UserManager<AccountResponse> UserManager;

            protected GoogleBaseController(UserManager<AccountResponse> userManager)
            {
                UserManager = userManager;
            }

        protected async Task<AccountResponse> GetCurrentUserAsync() => await UserManager.FindByIdAsync(User.Identity.Name);
        protected string GetUserId() =>User.Identity.Name;
        protected IActionResult ReturnBadRequest(ILogger _logger, Exception e)
        {
            _logger.LogError("Get property Failed" + e);
            return BadRequest(e.Message);
        }
    }
}

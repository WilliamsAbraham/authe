﻿namespace WashryteAPI.Models.StaffAccounts
{
    public class UserUpdatePasswordResponse
    {


        public string CurrentPassword { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}

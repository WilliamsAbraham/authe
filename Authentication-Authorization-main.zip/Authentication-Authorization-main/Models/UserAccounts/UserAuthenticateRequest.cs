﻿using System.ComponentModel.DataAnnotations;

namespace WashryteAPI.Models.StaffAccounts
{
    public class UserAuthenticateRequest
    {

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }
    }
}

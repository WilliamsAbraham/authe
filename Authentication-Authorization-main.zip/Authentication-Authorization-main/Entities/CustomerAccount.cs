﻿using System;
//using Microsoft.AspNetCore.Identity;

using System.Collections.Generic;

namespace WashryteAPI.Entities
{
    public class Customer
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string customer_id { get; set; }
        public string social_auth_id { get; set; }
        public string firstname { get; set; }
        public string lastName { get; set; }
        public string username { get; set; }    
        public string address { get; set; }
        public byte[] image { get; set; }

        public string provider { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string password { get; set; }

        public string reset_token { get; set; }
        public DateTime? reset_token_expired_at { get; set; }
        public DateTime? password_reset_at { get; set; }
        public string access_token { get; set; }    
     
        public DateTime created_at { get; set; }
        public DateTime? updated_at { get; set; }
        public DateTime? deleted_at { get; set; }

        public List<CustomerRefreshToken> CustomerRefreshTokens { get; set; }

        
        public bool OwnsToken (string Token)
        {
            return this.CustomerRefreshTokens.Find(x=>x.token == Token) !=null;
        }
        

        
    }
}

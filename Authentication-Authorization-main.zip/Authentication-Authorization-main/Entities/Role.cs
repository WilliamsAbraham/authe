﻿namespace WashryteAPI.Entities
{
    public enum Role
    {
        
        SuperAdmin,
        SubAdmin,
        SalesRep,
        NormalStaff
            
    }
}

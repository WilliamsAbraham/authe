﻿
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using static Google.Apis.Auth.GoogleJsonWebSignature;
using WashryteAPI.Entities;
using WashryteAPI.Models.Accounts;
namespace WashryteAPI.Services
{

    public interface IUserService
    {
        Task<AccountResponse> AuthenticateGoogleUserAsync(GoogleUserRequest request);
    }


    public class GoogleUserService : IUserService
    {
        protected readonly UserManager< AccountResponse> _userManager;

        public GoogleUserService(UserManager<AccountResponse> userManager) 
        { 
            _userManager = userManager;
        }
        public async Task<AccountResponse> AuthenticateGoogleUserAsync(GoogleUserRequest request)
        {
            Payload payload = await ValidateAsync(request.IdToken, new ValidationSettings
            {
                Audience = new [] { Startup.StaticConfig["Authentication:Google:ClientId"]}
            });

            return await GetorCreateExternalLoginUser(GoogleUserRequest.PROVIDER, payload.Subject, payload.Email, payload.GivenName, payload.FamilyName);
            
        }

        private async Task<AccountResponse> GetorCreateExternalLoginUser( string provider, string id, string email, string firstName, string lastName)
        {
            var user = await _userManager.FindByLoginAsync(provider, id);
            if (user == null)
                return user;
            user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                user = new AccountResponse
                {
                    Email = email,
                    UserName = email,
                    FirstName = firstName,
                    LastName = lastName,
                    
                    Social_auth_id = id
                };
                await _userManager.CreateAsync(user);

            }
               

            var info = new UserLoginInfo(provider, id, provider.ToUpperInvariant());
            var result = await _userManager.AddLoginAsync(user, info);
            if (result.Succeeded)
                return user;
            return null;
        }
        



    }
}


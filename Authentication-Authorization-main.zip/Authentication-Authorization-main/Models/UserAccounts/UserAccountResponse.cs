﻿using System;

namespace WashryteAPI.Models.StaffAccounts
{
    public class UserAccountResponse
    {

        public int Id { get; set; }
        public string Phone { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Store_id { get; set; }
        public string Bank_id { get; set; }
        public decimal Salary   { get; set; }
        public string Account_number { get; set; }
        public string Working_hours { get; set; }
        public bool Is_available { get; set; }
        public string JwtToken { get; set; }

        public string Role { get; set; }
        public DateTime Created { get; set; }
        public DateTime? Updated { get; set; }
        public DateTime? Deleted { get; set; }  
        
    }
}

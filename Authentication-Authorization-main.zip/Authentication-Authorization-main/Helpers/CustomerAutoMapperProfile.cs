﻿using AutoMapper;
using WashryteAPI.Entities;
using WashryteAPI.Models.Accounts;

namespace WashryteAPI.Helpers
{
    public class CustomerAutoMapperProfile : Profile
    {
        // mappings between model and entity objects
        public CustomerAutoMapperProfile()
        {
            CreateMap<Customer, AccountResponse>();


            CreateMap<Customer, AuthenticateResponse>();

            CreateMap<RegisterRequest, Customer>();

            CreateMap<UpdateRequest, Customer>();

            CreateMap<ResetPasswordRequest, Customer>();


            CreateMap<UpdatePasswordRequest, Customer > ()

                .ForAllMembers(x => x.Condition(
                    (src, dest, prop) =>
                    {
                        // ignore null & empty string properties
                        if (prop == null) return false;
                        if (prop.GetType() == typeof(string) && string.IsNullOrEmpty((string)prop)) return false;

                        // ignore null role
                        //if (x.DestinationMember.Name == "Role" && src.Role == null) return false;

                        return true;
                    }
                ));
        }
    }
}


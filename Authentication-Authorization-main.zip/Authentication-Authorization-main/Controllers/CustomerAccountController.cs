﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using WashryteAPI.Entities;
using WashryteAPI.Models.Accounts;
using WashryteAPI.Services;
using System.Collections.Generic;

namespace WashryteAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : BaseController
    {
        private readonly ICustomerAccountService _accountService;
        private readonly IMapper _mapper;

        public CustomerController(
            ICustomerAccountService accountService,
            IMapper mapper)
        {
            _accountService = accountService;
            _mapper = mapper;
        }

        [HttpPost("authenticate")]
        public ActionResult<AuthenticateResponse> Authenticate(AuthenticateRequest model)
        {
            var response = _accountService.Authenticate(model);
           
            return Ok(response);
        }


           
       

        [HttpPost("register")]
        public IActionResult Register(RegisterRequest model)
        {
            _accountService.Register(model, Request.Headers["origin"]);
            return Ok(new { message = "Registration successful, please check your email for verification instructions" });
        }

        
       

        [HttpPost("forgotpassword")]
        public IActionResult ForgotPassword(ForgotPasswordRequest model)
        {
            _accountService.ForgotPassword(model, Request.Headers["origin"]);
            return Ok(new { message = "Received, a mail with a code will be sent to your email if there is an account associated with it" });
            
        }

       
        
        
        [HttpPost("resetpassword")]
        public IActionResult ResetPassword(ResetPasswordRequest model)
        {
            _accountService.ResetPassword(model);
            return Ok(new { message = "Password reset successful, you can now login" });
        }

        [CustomerAuthorize]
        [HttpPatch("changepassword/{id:int}")]
        public IActionResult ChangePassword(int id, UpdatePasswordRequest model)
        {
            // users can Change their acccount only
            if (id != Customer.Id)
                return Unauthorized(new { message = "Unauthorized" });


                    _accountService.Changepassword(id, model);
            return Ok(new { message = "Password Changed Successfully" });
           


        }

       



    }
}

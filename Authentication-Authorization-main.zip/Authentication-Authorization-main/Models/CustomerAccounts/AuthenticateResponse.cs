﻿using System;
using System.Text.Json.Serialization;

namespace WashryteAPI.Models.Accounts
{
    public class AuthenticateResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public DateTime Created { get; set; }
        public string Social_auth_id  { get; set; }
        public DateTime? Updated { get; set; }
       
        public string access_token { get; set; }

        
    }
}

